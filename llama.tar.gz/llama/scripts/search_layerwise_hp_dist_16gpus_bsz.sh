disable_sdp=1
zero2=1
for bsz in 8 16 24 32 40 48 56 64 72 80;
do
echo llama_6656_52layer_full_fsdpoff${disable_sdp}_zero2_${zero2}_bsz${bsz}.file
nohup python search_layerwise_hp_dist.py \
--hidden_size 6656 \
--model_size 30B \
--layer_num 60 \
--memory_constraint 40 \
--search_from_min_bsz 1 \
--checkpoint 1 \
--type full \
--settle_bsz $bsz \
--disable_tp_consec 1 \
--disable_sdp $disable_sdp \
--use_zero2_for_dp $zero2 \
--mixed_precision 1 \
1> llama_6656_52layer_full_fsdpoff${disable_sdp}_zero2_${zero2}_bsz${bsz}.file 2>&1 &
done