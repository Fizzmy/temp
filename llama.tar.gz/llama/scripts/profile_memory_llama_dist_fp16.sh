hidden_size=6656
num_att_head=52
seqlen=2048
bsz=8

ARGS="--global_train_batch_size $bsz \
    --vocab_size 32000 \
    --hidden_size $hidden_size \
    --num_attention_heads $num_att_head \
    --seq_length $seqlen \
    --max-position-embeddings $seqlen \
    --epochs 10 \
    --lr 1e-4 \
    --adam_weight_decay 0.01 \
    --dropout_prob 0.1 \
    --check_loss 0 \
    --global_tp_consec 1 \
    --chunks 1 \
    --fsdp 0 \
    --profile 1 \
    --apply_strategy 0 \
    --save_profiled_memory 1"

for checkpoint in 0 1;
do
for pp_deg in 1;
do
for layernum in 1 2;
do
for tp_deg in 1 2 4 8;
do
if [ `expr $pp_deg \* $tp_deg` -le 8 ]; then
python -m torch.distributed.launch --nproc_per_node=8 --master_port 9996 train_hp_layerwise_dist_mp.py $ARGS \
--pp_deg $pp_deg \
--global_tp_deg $tp_deg \
--num_hidden_layers $layernum \
--global_checkpoint $checkpoint
fi
done
done
done
done

for pp_deg in 2 4 8;
do
for layernum in $pp_deg;
do
for tp_deg in 1 2 4 8;
do
if [ `expr $pp_deg \* $tp_deg` -le 8 ]; then
python -m torch.distributed.launch --nproc_per_node=8 --master_port 9996 train_hp_layerwise_dist_mp.py $ARGS \
--pp_deg $pp_deg \
--global_tp_deg $tp_deg \
--num_hidden_layers $layernum \
--global_checkpoint 0
fi
done
done
done