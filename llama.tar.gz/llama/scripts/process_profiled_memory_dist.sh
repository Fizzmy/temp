hidden_size=6656
num_att_head=52
seqlen=2048
python process_profiled_memory_dist.py \
--hidden_size $hidden_size \
--num_attention_heads $num_att_head \
--seq_length $seqlen \
--gpu_num 8 \
--use_fp16 1
