import torch.nn as nn
import torch
from typing import Optional

class LlamaEmbeddings_(nn.Module):
    def __init__(self,llama_model):
        super().__init__()
        self.embed_tokens = llama_model.model.embed_tokens
        # self._prepare_decoder_attention_mask = llama_model.model._prepare_decoder_attention_mask
    
    def forward(self, input_ids, attention_mask):
        inputs_embeds = self.embed_tokens(input_ids)
        # attention_mask = self._prepare_decoder_attention_mask(
        #     attention_mask, (batch_size, seq_length), inputs_embeds, 0
        # )
        return inputs_embeds, attention_mask
    

class LlamaDecoder_(nn.Module):
    def __init__(self, llama_model, layer_idx_start, layer_idx_end):
        super().__init__()
        self.layers = llama_model.model.layers[layer_idx_start:layer_idx_end]
    
    def forward(self, hidden_states, attention_mask):

        for i, layer_module in enumerate(self.layers):
            layer_outputs = layer_module(
                hidden_states = hidden_states,
                attention_mask = attention_mask
            )
            hidden_states = layer_outputs[0]

        return hidden_states, attention_mask

class LlamaRMSNorm_(nn.Module):
    def __init__(self, llama_model):
        super().__init__()
        self.norm = llama_model.model.norm
    
    def forward(self, hidden_states, attention_mask):
        hidden_states = self.norm(hidden_states)
        return hidden_states

class LlamaCls_(nn.Module):
    def __init__(self, llama_model):
        super().__init__()
        self.lm_head = llama_model.lm_head
    
    def forward(self, hidden_states):
        logits = self.lm_head(hidden_states)
        return logits
